﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace ABSA_Assessment
{
    public class DataLayer
    { 
        public DataLayer()
        {
        }

        public DataTable GetAllPhoneBookNames()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("PhoneBookID");
            dt.Columns.Add("Name");
            
            PhoneDbEntities db = new PhoneDbEntities();

            List<PhoneBook> ts = db.PhoneBooks.ToList();

            foreach( var a in ts)
            {
                 DataRow dr = dt.NewRow();

                dr["PhoneBookID"] = a.PhoneBookID;
                dr["Name"] =a.Name;
                dt.Rows.Add(dr);
            }

            return dt;
        }

        public DataTable GetAllPhoneEntriesforBook(long ID, string search)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("EntryID");
            dt.Columns.Add("Name");
            dt.Columns.Add("PhoneNumber");

            PhoneDbEntities db = new PhoneDbEntities();

           var query = (from t1 in db.PhoneBookEntries
             join t2 in db.PhoneBookToEntriesMappings on t1.EntryID equals t2.EntryID
             where t2.PhoneBookID == ID && t1.Name.Contains(search)
             select t1);

            List<PhoneBookEntry> ts =  query.ToList();

            foreach (var a in ts)
            {
                DataRow dr = dt.NewRow();

                dr["EntryID"] = a.EntryID;
                dr["Name"] = a.Name;
                dr["PhoneNumber"] = a.PhoneNumber;
                dt.Rows.Add(dr);
            }

            return dt;
        }

        public DataTable GetAllPhoneEntriesforBook(long ID)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("EntryID");
            dt.Columns.Add("Name");
            dt.Columns.Add("PhoneNumber");

            PhoneDbEntities db = new PhoneDbEntities();

            var query = (from t1 in db.PhoneBookEntries
                         join t2 in db.PhoneBookToEntriesMappings on t1.EntryID equals t2.EntryID
                         where t2.PhoneBookID == ID 
                         select t1);

            List<PhoneBookEntry> ts = query.ToList();

            foreach (var a in ts)
            {
                DataRow dr = dt.NewRow();

                dr["EntryID"] = a.EntryID;
                dr["Name"] = a.Name;
                dr["PhoneNumber"] = a.PhoneNumber;
                dt.Rows.Add(dr);
            }

            return dt;
        }

        public void AddorUpdatePhoneEntry(long ID, long EntryID, string Name, string PhoneNumber)
        {
            PhoneDbEntities db = new PhoneDbEntities();
            db.InsertintoPhoneBookNumbers(ID, EntryID, Name, PhoneNumber);
           
        }

        public void AddorUpdatePhoneName(long ID, string Name)
        {
            PhoneDbEntities db = new PhoneDbEntities();
            PhoneBook pb = new PhoneBook();
            pb.Name = Name;
            if (ID != -1)
            {                
                var s = (from book in db.PhoneBooks where book.PhoneBookID == ID select book).FirstOrDefault();
                s.Name = Name;
            }
            else
            {
                db.PhoneBooks.Add(pb);
            }
            db.SaveChanges();
        }

        public void DeletePhoneBook(long ID)
        {
            PhoneDbEntities db = new PhoneDbEntities();
            PhoneBook pb = new PhoneBook();
            var s = (from book in db.PhoneBooks where book.PhoneBookID == ID select book).FirstOrDefault();
            db.PhoneBooks.Remove(s);
            db.SaveChanges();
        }

        public void DeletePhoneBookEntry(long ID, long EntryID)
        {
            PhoneDbEntities db = new PhoneDbEntities();
            var l = (from entry in db.PhoneBookToEntriesMappings where entry.EntryID == EntryID && entry.PhoneBookID == ID select entry).FirstOrDefault();
            db.PhoneBookToEntriesMappings.Remove(l);
            var s = (from entry in db.PhoneBookEntries where entry.EntryID == EntryID select entry).FirstOrDefault();
            db.PhoneBookEntries.Remove(s);
            db.SaveChanges();
        }

        public void DeleteAllPhoneBookEntries(long PhoneBookID)
        {
            PhoneDbEntities db = new PhoneDbEntities();
            var s = (from t1 in db.PhoneBookEntries
                     join t2 in db.PhoneBookToEntriesMappings on t1.EntryID equals t2.EntryID 
                     where t2.PhoneBookID  == PhoneBookID select t1).FirstOrDefault();
            var l = (from entry in db.PhoneBookToEntriesMappings where entry.PhoneBookID == PhoneBookID select entry).FirstOrDefault();

            if (l != null)
             db.PhoneBookToEntriesMappings.Remove(l);
            if( s != null)
            db.PhoneBookEntries.Remove(s);
            db.SaveChanges();
        }

        public string PhoneBook(long ID)
        {

            PhoneDbEntities db = new PhoneDbEntities();
            var query = (from t1 in db.PhoneBooks where t1.PhoneBookID == ID select t1.Name).FirstOrDefault();
            return query.ToString();
        }
    }
}