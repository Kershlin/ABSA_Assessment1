﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ABSA_Assessment
{
    public partial class About : Page
    {
        private new long ID;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (Request.QueryString["ID"] != null)
            {
                ID = Convert.ToInt64(Request.QueryString["ID"]);
            }
            if (!IsPostBack)
            {
                PopulateDataGrid();
                DataLayer db = new DataLayer();

                lblHeading.Text = db.PhoneBook(ID);
            }


                
            

        }

        private void PopulateDataGrid()
        {

            DataLayer db = new DataLayer();
            grdEntries.Columns[0].Visible = true;
            grdEntries.DataSource = db.GetAllPhoneEntriesforBook(Convert.ToInt64(ID));
            grdEntries.DataBind();
            grdEntries.Columns[0].Visible = false;
        }

        protected void Addbtn_Click(object sender, ImageClickEventArgs e)
        {

            DataLayer db = new DataLayer();
            DataTable dt = db.GetAllPhoneEntriesforBook(ID);
            DataRow dr = dt.NewRow();
            dr["EntryID"] = -1;
            dr["Name"] = "";
            dr["PhoneNumber"] = "";
            dt.Rows.Add(dr);
            //grdPhoneBooks.Columns[0].Visible = true;

            grdEntries.DataSource = dt;
            grdEntries.DataBind();
            grdEntries.EditIndex = dt.Rows.Count - 1;
            grdEntries.DataBind();
            LinkButton bt = (LinkButton)grdEntries.Rows[dt.Rows.Count - 1].Cells[3].Controls[0];
            bt.Text = "Add";

            ((Label)grdEntries.Rows[dt.Rows.Count - 1].FindControl("lblID")).Visible = false;
        }

        protected void grdEntries_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdEntries.EditIndex = -1;
            PopulateDataGrid();
            lblError.Text = "";
        }

        protected void grdEntries_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            DataLayer db = new DataLayer();
            if (ValidateNumber(((TextBox)grdEntries.Rows[e.RowIndex].FindControl("tbNumber")).Text))
            {
                db.AddorUpdatePhoneEntry(ID, Convert.ToInt64(((Label)grdEntries.Rows[e.RowIndex].FindControl("lblID")).Text), ((TextBox)grdEntries.Rows[e.RowIndex].FindControl("tbName")).Text, ((TextBox)grdEntries.Rows[e.RowIndex].FindControl("tbNumber")).Text);
                grdEntries.EditIndex = -1;
                PopulateDataGrid();
                lblError.Text = "";
            }
        }

        protected void grdEntries_RowEditing(object sender, GridViewEditEventArgs e)
        {

            grdEntries.EditIndex = e.NewEditIndex;
            PopulateDataGrid();
            ((Label)grdEntries.Rows[e.NewEditIndex].FindControl("lblID")).Visible = false;
        }

        private bool IsNumber(string Number)
        {
            long n;
            bool isNumeric = Int64.TryParse(Number, out n);
            return isNumeric;
        }

        private bool ValidateNumber(string Number)
        {
            if (Number.Length < 10)
            {
                lblError.Text = "South African Phone Number including area code must be ten digits !!!";
                return false;
            }
            else if (IsNumber(Number) == false)
            {
                lblError.Text = "Invalid characters in Phone Number field !!!  Please enter only numeric values.";
                return false;
            }
            else
                return true;
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void tbSearch_TextChanged(object sender, EventArgs e)
        {
          
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
  DataLayer db = new DataLayer();
            grdEntries.Columns[0].Visible = true;
            grdEntries.DataSource = db.GetAllPhoneEntriesforBook(Convert.ToInt64(ID),((TextBox)grdEntries.HeaderRow.FindControl("tbSearch")).Text);
            grdEntries.DataBind();
            grdEntries.Columns[0].Visible = false;
        }

        protected void grdEntries_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            DataLayer db = new DataLayer();
            db.DeletePhoneBookEntry(ID,Convert.ToInt64((grdEntries.Rows[e.RowIndex].Cells[0].Text)));
            grdEntries.EditIndex = -1;
            PopulateDataGrid();
        }
    }
}