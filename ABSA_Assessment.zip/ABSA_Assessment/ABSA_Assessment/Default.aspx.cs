﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ABSA_Assessment
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PopulateDataGrid();

            }
        }

        protected void Addbtn_Click(object sender, ImageClickEventArgs e)
        {
            DataLayer db = new DataLayer();
            DataTable dt = db.GetAllPhoneBookNames();
            DataRow dr = dt.NewRow();
            dr["PhoneBookID"] = -1;
            dr["Name"] = "";
            dt.Rows.Add(dr);
            //grdPhoneBooks.Columns[0].Visible = true;

            grdPhoneBooks.DataSource = dt;
            grdPhoneBooks.DataBind();
            grdPhoneBooks.EditIndex = dt.Rows.Count - 1;
            grdPhoneBooks.DataBind();
            LinkButton bt = (LinkButton)grdPhoneBooks.Rows[dt.Rows.Count - 1].Cells[2].Controls[0];
            bt.Text = "Add";

            ((Label)grdPhoneBooks.Rows[dt.Rows.Count - 1].FindControl("lblID")).Visible = false;



        }

        private void PopulateDataGrid()
        {
            grdPhoneBooks.Columns[0].Visible = true;
            DataLayer db = new DataLayer();
            grdPhoneBooks.DataSource = db.GetAllPhoneBookNames();
            grdPhoneBooks.DataBind();
            grdPhoneBooks.Columns[0].Visible = false;
        }

        protected void grdPhoneBooks_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdPhoneBooks.EditIndex = -1;
            PopulateDataGrid();
        }

        protected void grdPhoneBooks_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grdPhoneBooks.EditIndex = e.NewEditIndex;
            PopulateDataGrid();
            ((Label)grdPhoneBooks.Rows[e.NewEditIndex].FindControl("lblID")).Visible = false;

        }

        protected void grdPhoneBooks_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            DataLayer db = new DataLayer();

            db.AddorUpdatePhoneName(Convert.ToInt64(((Label)grdPhoneBooks.Rows[e.RowIndex].FindControl("lblID")).Text), ((TextBox)grdPhoneBooks.Rows[e.RowIndex].FindControl("tbName")).Text);
            grdPhoneBooks.EditIndex = -1;
            PopulateDataGrid();

        }

        protected void grdPhoneBooks_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            DataLayer db = new DataLayer();

            db.DeleteAllPhoneBookEntries(Convert.ToInt64((grdPhoneBooks.Rows[e.RowIndex].Cells[0].Text)));
            db.DeletePhoneBook(Convert.ToInt64((grdPhoneBooks.Rows[e.RowIndex].Cells[0].Text)));
            grdPhoneBooks.EditIndex = -1;
            PopulateDataGrid();
        }

        protected void grdPhoneBooks_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && e.Row.RowState == DataControlRowState.Normal)
            {

                LinkButton delbutton = (LinkButton)e.Row.Cells[3].Controls[0];
                delbutton.OnClientClick = "if (!confirm('Please confirm that you want to delete this record?')) return;";

            }
        }
    }
}